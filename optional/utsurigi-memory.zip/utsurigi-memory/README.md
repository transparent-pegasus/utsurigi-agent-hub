# utsurigi-memory

Optional text memory: SQLite storage and cosine search with multilingual E5 or
explicit character hashing. Prefer the host's native memory. Installing this
package does not enable framework RAG or change existing instructions or tasks.

## Build

Requires Unix sockets, Bash, Rust with `std::fs::File::lock`, and C/C++ build tools.
No executable, model weights, database, or ONNX Runtime library is bundled.

```sh
bash build.sh
```

This installs `~/.local/bin/utsurigi-memory`; `bash utsurigi-memory ...` builds
it if missing. Build artifacts use `CARGO_TARGET_DIR`, or
`$XDG_CACHE_HOME/utsurigi-memory-target`, falling back to
`~/.cache/utsurigi-memory-target`. The locked dependencies are retained.

The default build downloads ONNX Runtime binaries through `ort-sys`. Those
static binaries can require newer glibc/C++ symbols than the host provides
(including `__isoc23_strtoll` on glibc 2.36). If linking fails, acquire the official
ONNX Runtime 1.24.2 CPU release for your platform and use its `lib` directory:

```sh
export ORT_LIB_PATH="/path/to/onnxruntime/lib"
export ORT_PREFER_DYNAMIC_LINK=1
export LD_LIBRARY_PATH="$ORT_LIB_PATH${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export RUSTFLAGS="-C link-arg=-Wl,-rpath,$ORT_LIB_PATH${RUSTFLAGS:+ $RUSTFLAGS}"
bash build.sh
```

The rpath also supports test children that clear their environment. Keep the
dynamic library at that location when running `utsurigi-memory`. This override was
verified on Linux x86_64; the default static build was not verified there.
Use [official releases](https://github.com/microsoft/onnxruntime/releases/tag/v1.24.2).

## Commands and paths

```sh
utsurigi-memory --hash add "Remember the project decision" --tag project
utsurigi-memory --hash search "project decision" -k 5
utsurigi-memory --json list
utsurigi-memory delete 1
utsurigi-memory info
utsurigi-memory snapshot /path/to/new-snapshot.db
```

`UTSURIGI_MEMORY_HOME`, `UTSURIGI_MEMORY_PATH`, `UTSURIGI_MEMORY_CACHE`,
`UTSURIGI_MEMORY_SOCK`, and `UTSURIGI_MEMORY_IDLE_SECS` override their defaults.
Empty values and empty XDG variables mean unset. `UTSURIGI_MEMORY_NO_DAEMON`
is the exception: its presence disables the daemon, even with an empty value.

The default data/model directory is `$XDG_DATA_HOME/utsurigi-memory`, falling back
to `$HOME/.local/share/utsurigi-memory`. The default database is `memory.db` inside
the selected `UTSURIGI_MEMORY_HOME` or default data/model directory.
`UTSURIGI_MEMORY_PATH` selects a database file; `--db FILE` overrides it and rejects
an omitted or empty FILE value.
Selected `UTSURIGI_MEMORY_PATH` and `UTSURIGI_MEMORY_SOCK` values must be
UTF-8.
The wrapper preserves these choices. All stored timestamp displays use UTC.

`--json`, `--hash`, `--tag`, `-k`, and `serve --idle SECS` retain their names.
SQLite tables `meta` and `memories` and their stored vector format are unchanged.
The first embedding pins `multilingual-e5-small` (384 dimensions) or
`char-ngram-hash-1024` (1024 dimensions). Different spaces cannot be mixed.
Existing hash databases require `--hash` for add/search. Invalid vector sizes,
non-finite values, and unreadable rows produce errors; `info` uses SQL COUNT.

`snapshot DESTINATION` opens the source read-only and uses SQLite `VACUUM INTO`
for a consistent export, including committed WAL data. It needs no model or
daemon, preserves records, and refuses every existing destination, including an
empty file. A missing source fails without creating a database. Check a snapshot
before adopting or backing it up.

## Model and daemon

There are **no model weights in this archive**. Missing, invalid, or checksum
mismatched models fail before opening a database or binding a new daemon socket.
Hashing is used only with explicit `--hash`; it is a weaker keyword-like mode.
`list`, `delete`, `info`, and `snapshot` need no inference.

Only when RAG is enabled and E5 is selected, acquire the compatible fp32 model:

```sh
model_dir="${UTSURIGI_MEMORY_HOME:-${XDG_DATA_HOME:-$HOME/.local/share}/utsurigi-memory}/model/multilingual-e5-small"
mkdir -p "$model_dir"
cp model/multilingual-e5-small/*.json model/multilingual-e5-small/model.onnx.sha256 "$model_dir/"
curl --fail --location --output "$model_dir/model.onnx" \
  https://huggingface.co/intfloat/multilingual-e5-small/resolve/614241f622f53c4eeff9890bdc4f31cfecc418b3/onnx/model.onnx
(cd "$model_dir" && sha256sum --check model.onnx.sha256)
```

The pinned model SHA256 is
`ca456c06b3a9505ddfd9131408916dd79290368331e7d76bb621f1cba6bc8665`.
Its tokenizer/config files are included; see [MODEL-NOTICE.md](MODEL-NOTICE.md).
Keep the checksum file beside the weights. Ordered `model.onnx.partNN` files
remain supported: they are joined into the runtime cache. Direct, joined, and
cached weights are all checksum verified. Remove an invalid cached model before
retrying. E5 uses mean pooling, `passage: ` for stored text, `query: ` for searches,
and L2 normalization. It is not a multimodal model.

E5 add/search auto-start `utsurigi-memory serve`. The daemon holds the model
and exits after `UTSURIGI_MEMORY_IDLE_SECS` of inactivity (default 600).
An invalid environment value uses 600; `serve --idle SECS` overrides it.
`utsurigi-memory status` leaves the idle
timer unchanged; `utsurigi-memory stop` stops it. Database operations stay in
the CLI. `UTSURIGI_MEMORY_NO_DAEMON` embeds in process whenever present;
`--hash` always runs in process.

`UTSURIGI_MEMORY_CACHE` overrides `$XDG_CACHE_HOME/utsurigi-memory` or
`$HOME/.cache/utsurigi-memory`. It holds `utsurigi-memory.sock`,
`utsurigi-memory.lock`, `utsurigi-memory.log`, and a joined `model.onnx`.
`UTSURIGI_MEMORY_SOCK` overrides the socket path. Use a local filesystem for
this directory and keep separate caches/sockets for separate model deployments.

## Verify

```sh
cargo fmt --check
cargo check --locked
cargo clippy --all-targets -- -D warnings
cargo test --locked
```

Use the runtime environment above when needed.
